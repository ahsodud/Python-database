DROP TABLE IF EXISTS Book, Author, Genre, Users, Country, BookGenre, AuthorBook, Friendship, Rating;

CREATE TABLE Country (
    ISO_3166 CHAR(2) PRIMARY KEY,
    CountryName VARCHAR(256),
    CID varchar(16)
);
CREATE TABLE Users (
    UID INT PRIMARY KEY,
    Username VARCHAR(256),
    DoB DATE,
    Age INT,
    ISO_3166 CHAR(2) REFERENCES Country (ISO_3166)
);
CREATE TABLE Book (
    ISBN VARCHAR(17) PRIMARY KEY,
    Title VARCHAR(256),
    Published DATE,
    Pages INT,
    Language VARCHAR(256)
);
CREATE TABLE Rating (
    UID INT REFERENCES Users (UID),
    ISBN VARCHAR(17) REFERENCES Book (ISBN),
    PRIMARY KEY (UID,ISBN),
    Rating INT
);
CREATE TABLE Friendship (
    User1 INT REFERENCES Users (UID),
    User2 INT REFERENCES Users (UID),
    PRIMARY KEY (User1, User2),
    CONSTRAINT columns_cannot_equal CHECK (User1 <> User2)
);
CREATE TABLE Author (
    AID INT PRIMARY KEY,
    AuthorName VARCHAR (256)
);
CREATE TABLE AuthorBook (
    AID INT REFERENCES Author (AID),
    ISBN VARCHAR(17) REFERENCES Book (ISBN),
    PRIMARY KEY (AID,ISBN)
);
CREATE TABLE Genre (
    GID INT PRIMARY KEY,
    GenreName VARCHAR (256)
);
CREATE TABLE BookGenre (
    ISBN VARCHAR(17) REFERENCES Book (ISBN),
    GID INT REFERENCES Genre (GID),
    PRIMARY KEY (ISBN,GID)
);
